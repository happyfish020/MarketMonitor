def decide_action_by_gate(gate: dict) -> dict:
    pass