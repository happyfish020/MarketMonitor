"""US 市场 datasource 占位文件，后续扩展使用。"""
